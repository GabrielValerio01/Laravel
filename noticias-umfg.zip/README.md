# Página de Notícias UMFG

**Para acessar o ambiente administrativo, utilize as seguintes credenciais:**

- Email: admin@admin.com
- Senha: password

## Descrição

A página apresenta notícias e informações sobre a Faculdade UMFG. Ela exibe uma barra lateral, um cabeçalho com o logo da universidade e um link para acessar a área administrativa.

![Página de Notícias UMFG](https://umfg.edu.br/wp-content/uploads/2020/03/foto-novo-campus-scaled.jpg)

## Notícias

A seção de notícias exibe uma grade de notícias, cada uma com uma imagem, título, e descrição. Abaixo de cada notícia, há um link para saber mais sobre ela.

## Cursos

A seção de cursos apresenta alguns cursos oferecidos pela UMFG, cada um com uma imagem e uma descrição.

## Rodapé

No rodapé da página, há o logo da universidade.
